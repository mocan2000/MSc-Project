package com.mini.project.nfcreader;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;
import java.util.concurrent.*;

public class MainActivity extends AppCompatActivity
{

	private Button switchButton;
	private boolean isTurnedOn = false;
	private NfcAdapter mNfcAdapter;

	//SERVER IP SHOULD BE CHANGED ACCORDINGLY
	//IT SHOULD ALSO BE CHANGED IN res/xml/network_security_config.xml AS WELL

	private String serverIP = "192.168.1.71";
	private int serverPort = 1234;

	private boolean connected = false;

	private SocketClient client;

	private String defaultNFCTagID = "nfcDemo";

	@Override
	protected void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		setContentView( R.layout.activity_main );
		switchButton = findViewById( R.id.switch_button );


		Thread t = new Thread( new Runnable()
		{
			public void run()
			{
				client = registerConnectionWithSocketServer();
			}
		} );
		t.start();

		switchButton.setOnClickListener( new View.OnClickListener()

		{
			@Override
			public void onClick( View view )
			{
				if ( client == null )
				{
					Toast.makeText( getApplicationContext(), "Error! Couldn't connect to the server.",
							Toast.LENGTH_SHORT )
							.show();
				}

				else
				{
					if ( !isTurnedOn )
					{

						switchButton.setText( "Turn OFF" );
						isTurnedOn = true;
						sendMessageOnNewThread( "ON" );
					}

					else
					{
						switchButton.setText( "Turn ON" );
						isTurnedOn = false;

						sendMessageOnNewThread( "OFF" );
					}

				}
			}
		} );
	}

	private void sendMessageOnNewThread( final String sendMsg )
	{

		ExecutorService executorService = Executors.newSingleThreadExecutor();
		Callable<String> callable = new Callable<String>()
		{
			@Override
			public String call() throws Exception
			{
				return sendMessage( sendMsg, client );
			}
		};

		Future<String> future = executorService.submit( callable );

		try
		{
			String message = future.get();
			Toast.makeText( getApplicationContext(), message,
					Toast.LENGTH_SHORT )
					.show();
		}
		catch ( ExecutionException e )
		{
			e.printStackTrace();
		}
		catch ( InterruptedException e )
		{
			e.printStackTrace();
		}

	}

	private SocketClient registerConnectionWithSocketServer()
	{
		SocketClient client = new SocketClient();

		try
		{
			client.startConnection( serverIP, serverPort );
			String response = null;
			response = client.sendMessage( "{0: 'mobilePhone1', 1: 'phone', 2: '" + defaultNFCTagID + "'}" );
			return client;
		}
		catch ( IOException e )
		{
			return null;
		}
	}

	private String sendMessage( String message, SocketClient client )
	{
		try
		{
			String response = client.sendMessage( "{0:'mobilePhone1', 1:'raspberry1',2:'" + message + "'}" );
			return response;
		}
		catch ( IOException e )
		{
			return "Error! Couldn't connect to the server.";
		}
	}
}