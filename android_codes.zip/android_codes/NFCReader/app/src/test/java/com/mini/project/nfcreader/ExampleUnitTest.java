package com.mini.project.nfcreader;

import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }

    @Test
    public void sendDataAfterSomeTimeRaspberryPiNotConnected() {
        SocketClient client = new SocketClient();
        try
        {
            client.startConnection( "127.0.0.1", 1234 );
            String response = null;

            response = client.sendMessage( "{0: 'mobilePhone1', 1: 'phone', 2: 'testPwd'}" );
            assertEquals( "connection success!", response );
            try
            {
                Thread.sleep( 1000 );
            }
            catch ( InterruptedException e )
            {
                e.printStackTrace();
            }
            response = client.sendMessage( "{0:'mobilePhone1', 1:'raspberry1',2:'ON'}" );
            assertEquals( "device not connected with the server", response );
        }

        catch ( IOException e )
        {
            e.printStackTrace();
        }

    }

    @Test
    public void sendDataAfterSomeTimeRaspberryPiConnected() {
        SocketClient client = new SocketClient();
        try
        {
            client.startConnection("127.0.0.1", 1234);
            String response = null;

            response = client.sendMessage("{0: 'mobilePhone1', 1: 'phone', 2: 'testPwd'}");
            assertEquals("connection success!", response);
            try
            {
                Thread.sleep( 1000 );
            }
            catch ( InterruptedException e )
            {
                e.printStackTrace();
            }
            response = client.sendMessage( "{0:'mobilePhone1', 1:'raspberry1',2:'ON'}" );
            assertEquals( "data sent!", response );

            response = client.sendMessage( "{0:'mobilePhone1', 1:'raspberry1',2:'OFF'}" );
            assertEquals( "data sent!", response );
        }

        catch ( IOException e )
        {
            e.printStackTrace();
        }

    }

}